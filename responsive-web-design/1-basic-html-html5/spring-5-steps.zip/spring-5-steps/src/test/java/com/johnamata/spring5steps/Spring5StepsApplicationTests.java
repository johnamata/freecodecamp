package com.johnamata.spring5steps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring5StepsApplicationTests {

	@Test
	void contextLoads() {
	}

}
